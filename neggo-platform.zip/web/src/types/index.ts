export type ProductType =
  | 'llamada'
  | 'credito'
  | 'cdt'
  | 'tarjeta'
  | 'compra-cartera'
  | 'hipotecario'
  | 'libranza'
  | 'vehiculo'
  | 'inversion';

export type ClientType =
  | 'cliente-banco'
  | 'no-cliente'
  | 'premium'
  | 'nomina'
  | 'alto-patrimonio'
  | 'riesgo'
  | 'prospecto';

export type LeadStatus =
  | 'pendiente'
  | 'contactado'
  | 'en-proceso'
  | 'documentacion'
  | 'viable'
  | 'aprobado'
  | 'desembolsado'
  | 'perdido';

export type Priority = 'baja' | 'media' | 'alta' | 'maxima';

export type RiskLevel = 'alto' | 'medio' | 'bajo' | 'minimo';

export type CampaignType =
  | 'cdt'
  | 'hipotecario'
  | 'compra-cartera'
  | 'tarjetas'
  | 'libranzas'
  | 'vehiculos'
  | 'inversiones';

export type FeedbackType = 'felicitacion' | 'problema' | 'sugerencia' | 'mala-atencion';

export type FeedbackStatus = 'nuevo' | 'en-proceso' | 'resuelto' | 'escalado';

export interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string;
  product: ProductType;
  clientType: ClientType;
  score: number;
  priority: Priority;
  status: LeadStatus;
  lastActivity: string;
  assignedTo: string;
  city: string;
  bank: string;
  campaign?: string;
  income?: number;
  notes?: string;
  createdAt: string;
}

export interface KPIData {
  totalSolicitudes: number;
  convertidas: number;
  tasaConversion: number;
  scorePromedio: number;
  altaPrioridad: number;
  leadsRiesgo: number;
  deltaSolicitudes: number;
  deltaConversion: number;
  deltaScore: number;
  deltaPrioridad: number;
}

export interface Campaign {
  id: string;
  name: string;
  type: CampaignType;
  bank: string;
  impressions: number;
  ctr: number;
  leadsGenerated: number;
  conversions: number;
  avgScore: number;
  budget: number;
  spent: number;
  startDate: string;
  endDate: string;
  status: 'activa' | 'pausada' | 'finalizada';
  cities: string[];
}

export interface Feedback {
  id: string;
  clientName: string;
  type: FeedbackType;
  status: FeedbackStatus;
  rating: number;
  comment: string;
  bank: string;
  createdAt: string;
  respondedAt?: string;
  response?: string;
  satisfactionScore?: number;
}

export interface ProyectoConstructora {
  id: string;
  name: string;
  city: string;
  units: number;
  priceRangeMin: number;
  priceRangeMax: number;
  leadsGenerated: number;
  hipotecarioInterest: number;
  avgScore: number;
  conversionRate: number;
  status: 'activo' | 'vendido' | 'pausado';
  constructora: string;
  tipoVivienda: 'apartamento' | 'casa' | 'local' | 'oficina';
}

export interface LeadInmobiliario {
  id: string;
  name: string;
  phone: string;
  email: string;
  capacidadCompra: number;
  score: number;
  hipotecarioInterest: boolean;
  ingresosEstimados: number;
  city: string;
  tipoVivienda: string;
  prioridad: Priority;
  proyecto: string;
  status: LeadStatus;
  lastActivity: string;
  assignedTo: string;
  createdAt: string;
}

export interface PipelineStatus {
  label: string;
  value: number;
  total: number;
  color: string;
}

export interface SystemStatus {
  label: string;
  status: 'operativo' | 'degradado' | 'critico' | 'mantenimiento';
  latency: string;
  uptime: string;
}

export interface AnalyticMetric {
  label: string;
  value: number;
  previousValue: number;
  delta: number;
  format?: 'number' | 'percent' | 'currency';
}
