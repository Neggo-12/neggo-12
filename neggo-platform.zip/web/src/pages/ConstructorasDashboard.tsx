import { useState, useMemo } from 'react';
import {
  Building2, Users, TrendingUp, MapPin, Home, DollarSign,
  Target, Award, Search, SlidersHorizontal, ChevronDown, ChevronUp,
  Phone, MessageCircle, Eye, ArrowRightLeft
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import ScoreBadge from '@/components/ScoreBadge';
import PriorityBadge from '@/components/PriorityBadge';
import LeadStatusBadge from '@/components/LeadStatusBadge';
import { proyectos, leadsInmobiliarios } from '@/data/mock';
import { cn } from '@/lib/utils';
import type { LeadInmobiliario, ProyectoConstructora } from '@/types';

export default function ConstructorasDashboard() {
  const [search, setSearch] = useState('');
  const [activeProject, setActiveProject] = useState<string | null>(null);
  const [expandedLead, setExpandedLead] = useState<string | null>(null);

  const filteredLeads = useMemo(() => {
    let result = [...leadsInmobiliarios];
    if (activeProject) {
      result = result.filter((l) => l.proyecto === activeProject);
    }
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (l) =>
          l.name.toLowerCase().includes(q) ||
          l.phone.includes(q) ||
          l.proyecto.toLowerCase().includes(q)
      );
    }
    return result;
  }, [search, activeProject]);

  const totals = useMemo(() => {
    const active = proyectos.filter((p) => p.status === 'activo');
    return {
      proyectos: active.length,
      totalUnits: active.reduce((s, p) => s + p.units, 0),
      totalLeads: proyectos.reduce((s, p) => s + p.leadsGenerated, 0),
      avgConversion: proyectos.reduce((s, p) => s + p.conversionRate, 0) / proyectos.length,
      avgScore: Math.round(proyectos.reduce((s, p) => s + p.avgScore, 0) / proyectos.length),
      hipotecarioInterest: Math.round(proyectos.reduce((s, p) => s + p.hipotecarioInterest, 0) / proyectos.length),
    };
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-[1440px] space-y-6 p-4 lg:p-6">
        {/* Header */}
        <div className="relative overflow-hidden rounded-xl border border-border/60 bg-card/80 backdrop-blur-sm">
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
          <div className="flex items-center gap-4 px-5 py-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/10 glow-blue">
              <Building2 className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-foreground">Centro de Captación Inmobiliaria</h2>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-blue-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-blue-400" />
                </span>
                Operativo — {proyectos.filter((p) => p.status === 'activo').length} proyectos activos
              </div>
            </div>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {[
            { label: 'Proyectos Activos', value: totals.proyectos, icon: Building2, color: 'text-blue-400', bg: 'bg-blue-500/10' },
            { label: 'Unidades Totales', value: totals.totalUnits, icon: Home, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
            { label: 'Leads Totales', value: totals.totalLeads, icon: Users, color: 'text-purple-400', bg: 'bg-purple-500/10' },
            { label: 'Conversión Prom.', value: totals.avgConversion.toFixed(1) + '%', icon: TrendingUp, color: 'text-amber-400', bg: 'bg-amber-500/10' },
            { label: 'Score Promedio', value: totals.avgScore, icon: Award, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
            { label: 'Interés Hipotecario', value: totals.hipotecarioInterest + '%', icon: Target, color: 'text-pink-400', bg: 'bg-pink-500/10' },
          ].map((stat) => (
            <div key={stat.label} className="rounded-xl border border-border/40 bg-card/40 p-4">
              <div className={cn('flex h-8 w-8 items-center justify-center rounded-lg mb-2', stat.bg)}>
                <stat.icon className={cn('h-4 w-4', stat.color)} />
              </div>
              <div className="text-xl font-bold text-foreground font-mono">{stat.value}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Projects Section */}
        <div>
          <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
            <Building2 className="h-4 w-4 text-primary" />
            Proyectos Activos
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {proyectos.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                isActive={activeProject === project.name}
                onClick={() => setActiveProject(activeProject === project.name ? null : project.name)}
              />
            ))}
          </div>
        </div>

        {/* Leads Section */}
        <div>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-3">
            <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              Leads Inmobiliarios
              {activeProject && (
                <Badge variant="outline" className="text-xs border-border/40 bg-secondary/40">
                  {activeProject}
                  <button onClick={() => setActiveProject(null)} className="ml-1.5 hover:text-foreground">×</button>
                </Badge>
              )}
            </h3>
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar leads..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 bg-card/60 border-border/40 text-sm"
              />
            </div>
          </div>

          <div className="rounded-xl border border-border/40 bg-card/40 overflow-hidden">
            <div className="overflow-x-auto scrollbar-thin">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/40 bg-card/60">
                    <th className="px-3 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Cliente</th>
                    <th className="px-3 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground hidden md:table-cell">Capacidad</th>
                    <th className="px-3 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Score</th>
                    <th className="px-3 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground hidden lg:table-cell">Hipotecario</th>
                    <th className="px-3 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground hidden xl:table-cell">Ingresos</th>
                    <th className="px-3 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Ciudad</th>
                    <th className="px-3 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground hidden lg:table-cell">Tipo</th>
                    <th className="px-3 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Prioridad</th>
                    <th className="px-3 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Estado</th>
                    <th className="px-3 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/30">
                  {filteredLeads.map((lead) => (
                    <>
                      <tr
                        key={lead.id}
                        className="group transition-colors hover:bg-card/60 cursor-pointer"
                        onClick={() => setExpandedLead(expandedLead === lead.id ? null : lead.id)}
                      >
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-3">
                            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-500/10 text-xs font-bold text-blue-400">
                              {lead.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                            </div>
                            <div>
                              <div className="font-medium text-foreground">{lead.name}</div>
                              <div className="text-[11px] text-muted-foreground font-mono">{lead.id}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-3 py-3 hidden md:table-cell">
                          <span className="font-mono text-sm text-foreground">${(lead.capacidadCompra / 1000000).toFixed(1)}M</span>
                        </td>
                        <td className="px-3 py-3">
                          <ScoreBadge score={lead.score} showLabel={false} size="sm" />
                        </td>
                        <td className="px-3 py-3 hidden lg:table-cell">
                          {lead.hipotecarioInterest ? (
                            <Badge variant="outline" className="text-[10px] border-emerald-500/20 bg-emerald-500/10 text-emerald-400">
                              Interesado
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-[10px] border-slate-500/20 bg-slate-500/10 text-slate-400">
                              No interesado
                            </Badge>
                          )}
                        </td>
                        <td className="px-3 py-3 hidden xl:table-cell">
                          <span className="font-mono text-xs text-muted-foreground">${(lead.ingresosEstimados / 1000000).toFixed(1)}M</span>
                        </td>
                        <td className="px-3 py-3">
                          <span className="text-xs text-muted-foreground">{lead.city}</span>
                        </td>
                        <td className="px-3 py-3 hidden lg:table-cell">
                          <Badge variant="outline" className="text-[10px] border-border/40 bg-secondary/40 capitalize">
                            {lead.tipoVivienda}
                          </Badge>
                        </td>
                        <td className="px-3 py-3">
                          <PriorityBadge priority={lead.priority} />
                        </td>
                        <td className="px-3 py-3">
                          <LeadStatusBadge status={lead.status} />
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex items-center justify-end gap-1">
                            <button className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-all" title="Llamar">
                              <Phone className="h-3.5 w-3.5" />
                            </button>
                            <button className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-all" title="WhatsApp">
                              <MessageCircle className="h-3.5 w-3.5" />
                            </button>
                            <button className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-all" title="Ver perfil">
                              <Eye className="h-3.5 w-3.5" />
                            </button>
                            <button className="ml-1 p-1 rounded hover:bg-muted transition-colors">
                              {expandedLead === lead.id ? <ChevronUp className="h-3.5 w-3.5 text-muted-foreground" /> : <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />}
                            </button>
                          </div>
                        </td>
                      </tr>
                      {expandedLead === lead.id && (
                        <tr>
                          <td colSpan={11} className="px-3 py-4 bg-card/30 border-b border-border/20">
                            <ExpandedInmobiliario lead={lead} />
                          </td>
                        </tr>
                      )}
                    </>
                  ))}
                </tbody>
              </table>
            </div>
            {filteredLeads.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <Search className="h-10 w-10 text-muted-foreground/40 mb-3" />
                <p className="text-sm font-medium text-muted-foreground">No se encontraron leads</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function ProjectCard({ project, isActive, onClick }: { project: ProyectoConstructora; isActive: boolean; onClick: () => void }) {
  const statusConfig = {
    activo: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20' },
    vendido: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/20' },
    pausado: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20' },
  };
  const cfg = statusConfig[project.status];

  return (
    <div
      onClick={onClick}
      className={cn(
        'group cursor-pointer rounded-xl border p-4 transition-all hover:scale-[1.01]',
        isActive ? 'border-blue-500/40 bg-blue-500/5' : 'border-border/40 bg-card/40 hover:border-border/60 hover:bg-card/60'
      )}
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <h4 className="text-sm font-semibold text-foreground">{project.name}</h4>
          <div className="flex items-center gap-2 mt-1">
            <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <MapPin className="h-3 w-3" /> {project.city}
            </span>
            <span className={cn('rounded-full border px-2 py-0.5 text-[10px] font-medium', cfg.bg, cfg.text, cfg.border)}>
              {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
            </span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs font-mono text-muted-foreground">
            ${(project.priceRangeMin / 1000000).toFixed(0)}M - ${(project.priceRangeMax / 1000000).toFixed(0)}M
          </div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2 mb-3">
        <div className="text-center">
          <div className="text-sm font-bold text-foreground font-mono">{project.units}</div>
          <div className="text-[10px] text-muted-foreground">Unidades</div>
        </div>
        <div className="text-center">
          <div className="text-sm font-bold text-foreground font-mono">{project.leadsGenerated}</div>
          <div className="text-[10px] text-muted-foreground">Leads</div>
        </div>
        <div className="text-center">
          <div className="text-sm font-bold text-foreground font-mono">{project.hipotecarioInterest}%</div>
          <div className="text-[10px] text-muted-foreground">Hipotecario</div>
        </div>
        <div className="text-center">
          <div className="text-sm font-bold text-foreground font-mono">{project.conversionRate}%</div>
          <div className="text-[10px] text-muted-foreground">Conversión</div>
        </div>
      </div>

      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-1">
          <Award className="h-3 w-3 text-primary" />
          <span className="text-muted-foreground">Score promedio:</span>
          <span className="font-mono font-semibold text-foreground">{project.avgScore}</span>
        </div>
        <span className="text-[10px] text-muted-foreground">{project.constructora}</span>
      </div>
    </div>
  );
}

function ExpandedInmobiliario({ lead }: { lead: LeadInmobiliario }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="space-y-3">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Perfil Financiero</h4>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="rounded-lg bg-card/60 border border-border/30 p-2.5">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Score Datacrédito</div>
            <ScoreBadge score={lead.score} showLabel={true} size="md" />
          </div>
          <div className="rounded-lg bg-card/60 border border-border/30 p-2.5">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Capacidad de Compra</div>
            <div className="text-sm font-semibold text-foreground font-mono">
              ${(lead.capacidadCompra / 1000000).toFixed(1)}M
            </div>
          </div>
          <div className="rounded-lg bg-card/60 border border-border/30 p-2.5">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Ingresos Estimados</div>
            <div className="text-sm font-semibold text-foreground font-mono">
              ${(lead.ingresosEstimados / 1000000).toFixed(1)}M
            </div>
          </div>
          <div className="rounded-lg bg-card/60 border border-border/30 p-2.5">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Interés Hipotecario</div>
            <div className={cn('text-sm font-semibold', lead.hipotecarioInterest ? 'text-emerald-400' : 'text-slate-400')}>
              {lead.hipotecarioInterest ? 'Sí — Alto potencial' : 'No confirmado'}
            </div>
          </div>
        </div>
      </div>
      <div className="space-y-3">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Datos del Lead</h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-muted-foreground">Proyecto</span><span className="font-medium">{lead.proyecto}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Ciudad</span><span className="font-medium">{lead.city}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Tipo Vivienda</span><span className="font-medium capitalize">{lead.tipoVivienda}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Asignado a</span><span className="font-medium">{lead.assignedTo}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Creado</span><span className="font-mono text-xs">{new Date(lead.createdAt).toLocaleDateString('es-CO')}</span></div>
        </div>
      </div>
      <div className="space-y-3">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Acciones Rápidas</h4>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" className="gap-1.5 text-xs bg-blue-600 hover:bg-blue-700">
            <Phone className="h-3.5 w-3.5" /> Llamar
          </Button>
          <Button size="sm" variant="outline" className="gap-1.5 text-xs border-border/40">
            <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
          </Button>
          <Button size="sm" variant="outline" className="gap-1.5 text-xs border-border/40">
            <ArrowRightLeft className="h-3.5 w-3.5" /> Mover Pipeline
          </Button>
          <Button size="sm" variant="outline" className="gap-1.5 text-xs border-border/40">
            <DollarSign className="h-3.5 w-3.5" /> Cotizar
          </Button>
        </div>
      </div>
    </div>
  );
}
