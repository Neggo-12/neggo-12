import type {
  Lead,
  KPIData,
  Campaign,
  Feedback,
  ProyectoConstructora,
  LeadInmobiliario,
  PipelineStatus,
  SystemStatus,
} from '@/types';

export const kpiData: KPIData = {
  totalSolicitudes: 1247,
  convertidas: 389,
  tasaConversion: 31.2,
  scorePromedio: 682,
  altaPrioridad: 156,
  leadsRiesgo: 84,
  deltaSolicitudes: 12.4,
  deltaConversion: 3.8,
  deltaScore: -2.1,
  deltaPrioridad: 8.7,
};

export const pipelineStatus: PipelineStatus[] = [
  { label: 'Nuevos Leads', value: 342, total: 1247, color: 'emerald' },
  { label: 'En Proceso', value: 521, total: 1247, color: 'blue' },
  { label: 'Documentacion', value: 234, total: 1247, color: 'amber' },
  { label: 'Aprobados', value: 150, total: 1247, color: 'green' },
];

export const systemStatus: SystemStatus[] = [
  { label: 'API Core', status: 'operativo', latency: '42ms', uptime: '99.97%' },
  { label: 'Datacrédito', status: 'operativo', latency: '128ms', uptime: '99.91%' },
  { label: 'Notificaciones', status: 'operativo', latency: '18ms', uptime: '99.99%' },
  { label: 'Campañas', status: 'degradado', latency: '340ms', uptime: '98.45%' },
];

const banks = ['Bancolombia', 'Davivienda', 'BBVA', 'Banco de Bogotá', 'Scotiabank', 'Itaú'];
const cities = ['Bogotá', 'Medellín', 'Cali', 'Barranquilla', 'Cartagena', 'Bucaramanga'];
const ejecutivos = ['Carlos Mendoza', 'Ana Torres', 'Luis Rivera', 'María Castro', 'Jorge Vargas', 'Diana Suárez'];
const campaignNames = ['Campaña CDT Primavera', 'Hipotecario Flexible 2024', 'Tarjeta Premium Plus', 'Libranza Express', 'Compra Cartera Activa'];

const productNames: Record<string, string> = {
  llamada: 'Llamada',
  credito: 'Crédito',
  cdt: 'CDT',
  tarjeta: 'Tarjeta',
  'compra-cartera': 'Compra Cartera',
  hipotecario: 'Hipotecario',
  libranza: 'Libranza',
  vehiculo: 'Vehículo',
  inversion: 'Inversión',
};

const clientTypeNames: Record<string, string> = {
  'cliente-banco': 'Cliente Banco',
  'no-cliente': 'No Cliente',
  premium: 'Premium',
  nomina: 'Nómina',
  'alto-patrimonio': 'Alto Patrimonio',
  riesgo: 'Riesgo',
  prospecto: 'Prospecto',
};

const statusNames: Record<string, string> = {
  pendiente: 'Pendiente',
  contactado: 'Contactado',
  'en-proceso': 'En Proceso',
  documentacion: 'Documentación',
  viable: 'Viable',
  aprobado: 'Aprobado',
  desembolsado: 'Desembolsado',
  perdido: 'Perdido',
};

const firstNames = ['Juan', 'María', 'Carlos', 'Ana', 'Luis', 'Diana', 'Jorge', 'Camila', 'Andrés', 'Valentina', 'Pedro', 'Sofía', 'Miguel', 'Laura', 'Fernando', 'Isabella', 'Diego', 'Paula', 'Ricardo', 'Natalia'];
const lastNames = ['García', 'Rodríguez', 'Martínez', 'López', 'González', 'Pérez', 'Sánchez', 'Ramírez', 'Torres', 'Flores', 'Rivera', 'Castro', 'Vargas', 'Suárez', 'Mendoza', 'Herrera', 'Jiménez', 'Ruiz', 'Álvarez', 'Moreno'];

function random<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomDate(daysBack: number = 30): string {
  const d = new Date();
  d.setDate(d.getDate() - Math.floor(Math.random() * daysBack));
  return d.toISOString();
}

export const leads: Lead[] = Array.from({ length: 24 }, (_, i) => {
  const score = Math.floor(300 + Math.random() * 650);
  let priority: 'baja' | 'media' | 'alta' | 'maxima';
  if (score <= 550) priority = 'baja';
  else if (score <= 700) priority = 'media';
  else if (score <= 850) priority = 'alta';
  else priority = 'maxima';

  const statuses: Lead['status'][] = ['pendiente', 'contactado', 'en-proceso', 'documentacion', 'viable', 'aprobado', 'desembolsado', 'perdido'];
  const products: Lead['product'][] = ['llamada', 'credito', 'cdt', 'tarjeta', 'compra-cartera', 'hipotecario', 'libranza', 'vehiculo', 'inversion'];
  const clientTypes: Lead['clientType'][] = ['cliente-banco', 'no-cliente', 'premium', 'nomina', 'alto-patrimonio', 'riesgo', 'prospecto'];

  return {
    id: `L-${1000 + i}`,
    name: `${random(firstNames)} ${random(lastNames)}`,
    phone: `3${Math.floor(100000000 + Math.random() * 900000000)}`,
    email: `cliente${i}@email.com`,
    product: random(products),
    clientType: random(clientTypes),
    score,
    priority,
    status: random(statuses),
    lastActivity: randomDate(7),
    assignedTo: random(ejecutivos),
    city: random(cities),
    bank: random(banks),
    campaign: random(campaignNames),
    income: Math.floor(2000000 + Math.random() * 18000000),
    createdAt: randomDate(60),
  };
});

export const campaigns: Campaign[] = [
  {
    id: 'C-001',
    name: 'CDT Primavera 2024',
    type: 'cdt',
    bank: 'Bancolombia',
    impressions: 245000,
    ctr: 4.2,
    leadsGenerated: 342,
    conversions: 89,
    avgScore: 745,
    budget: 50000000,
    spent: 34200000,
    startDate: '2024-03-01',
    endDate: '2024-05-31',
    status: 'activa',
    cities: ['Bogotá', 'Medellín', 'Cali'],
  },
  {
    id: 'C-002',
    name: 'Hipotecario Flexible',
    type: 'hipotecario',
    bank: 'Davivienda',
    impressions: 189000,
    ctr: 3.8,
    leadsGenerated: 278,
    conversions: 67,
    avgScore: 698,
    budget: 75000000,
    spent: 52100000,
    startDate: '2024-02-15',
    endDate: '2024-06-30',
    status: 'activa',
    cities: ['Bogotá', 'Barranquilla'],
  },
  {
    id: 'C-003',
    name: 'Tarjeta Premium Plus',
    type: 'tarjetas',
    bank: 'BBVA',
    impressions: 412000,
    ctr: 2.9,
    leadsGenerated: 156,
    conversions: 45,
    avgScore: 812,
    budget: 35000000,
    spent: 28900000,
    startDate: '2024-01-10',
    endDate: '2024-04-30',
    status: 'pausada',
    cities: ['Bogotá', 'Medellín', 'Cali', 'Cartagena'],
  },
  {
    id: 'C-004',
    name: 'Libranza Express',
    type: 'libranzas',
    bank: 'Banco de Bogotá',
    impressions: 98000,
    ctr: 5.1,
    leadsGenerated: 198,
    conversions: 72,
    avgScore: 634,
    budget: 28000000,
    spent: 19800000,
    startDate: '2024-04-01',
    endDate: '2024-07-15',
    status: 'activa',
    cities: ['Bogotá', 'Bucaramanga'],
  },
  {
    id: 'C-005',
    name: 'Compra Cartera Activa',
    type: 'compra-cartera',
    bank: 'Scotiabank',
    impressions: 156000,
    ctr: 3.5,
    leadsGenerated: 234,
    conversions: 78,
    avgScore: 712,
    budget: 42000000,
    spent: 31500000,
    startDate: '2024-03-15',
    endDate: '2024-06-15',
    status: 'activa',
    cities: ['Medellín', 'Cali'],
  },
  {
    id: 'C-006',
    name: 'Vehículo Nuevo 2024',
    type: 'vehiculos',
    bank: 'Itaú',
    impressions: 312000,
    ctr: 2.4,
    leadsGenerated: 189,
    conversions: 38,
    avgScore: 656,
    budget: 60000000,
    spent: 47800000,
    startDate: '2024-02-01',
    endDate: '2024-05-15',
    status: 'finalizada',
    cities: ['Bogotá', 'Medellín', 'Barranquilla'],
  },
];

export const feedbacks: Feedback[] = [
  {
    id: 'F-001',
    clientName: 'Roberto Méndez',
    type: 'felicitacion',
    status: 'resuelto',
    rating: 5,
    comment: 'Excelente atención por parte del asesor Carlos. Me ayudó a entender todos los beneficios del CDT y cerré en menos de 30 minutos.',
    bank: 'Bancolombia',
    createdAt: '2024-05-10T14:30:00Z',
    respondedAt: '2024-05-10T16:00:00Z',
    response: 'Gracias Roberto, nos alegra mucho tu experiencia. Seguiremos trabajando para brindarte el mejor servicio.',
    satisfactionScore: 9.5,
  },
  {
    id: 'F-002',
    clientName: 'Carmen Díaz',
    type: 'problema',
    status: 'en-proceso',
    rating: 2,
    comment: 'He intentado contactar a mi asesor tres veces y no responde. Necesito información urgente sobre mi solicitud de crédito hipotecario.',
    bank: 'Davivienda',
    createdAt: '2024-05-09T09:15:00Z',
    response: 'Lamentamos la situación Carmen. Hemos escalado tu caso al supervisor del área y te contactaremos en menos de 2 horas.',
  },
  {
    id: 'F-003',
    clientName: 'Alberto Ruiz',
    type: 'sugerencia',
    status: 'nuevo',
    rating: 4,
    comment: 'Sería muy útil poder ver el estado de mi solicitud en tiempo real desde la app, sin tener que llamar al call center.',
    bank: 'BBVA',
    createdAt: '2024-05-11T11:20:00Z',
  },
  {
    id: 'F-004',
    clientName: 'Patricia López',
    type: 'mala-atencion',
    status: 'escalado',
    rating: 1,
    comment: 'El asesor me trató con desprecio cuando pregunté sobre las tasas. Nunca había tenido una experiencia tan negativa.',
    bank: 'Banco de Bogotá',
    createdAt: '2024-05-08T16:45:00Z',
    response: 'Patricia, lamento profundamente esta situación. Tu caso ha sido escalado al Gerente de Experiencia del Cliente para una revisión inmediata.',
  },
  {
    id: 'F-005',
    clientName: 'Eduardo Silva',
    type: 'felicitacion',
    status: 'resuelto',
    rating: 5,
    comment: 'La plataforma es muy intuitiva. Pude comparar productos fácilmente y el proceso de solicitud fue súper rápido.',
    bank: 'Scotiabank',
    createdAt: '2024-05-11T08:00:00Z',
    respondedAt: '2024-05-11T10:30:00Z',
    response: '¡Gracias Eduardo! Tu feedback nos impulsa a seguir mejorando.',
    satisfactionScore: 10,
  },
  {
    id: 'F-006',
    clientName: 'Luz Márquez',
    type: 'problema',
    status: 'en-proceso',
    rating: 3,
    comment: 'El sistema no me dejó subir los documentos requeridos. Aparece un error cada vez que intento adjuntar PDFs.',
    bank: 'Itaú',
    createdAt: '2024-05-10T13:00:00Z',
    response: 'Hola Luz, nuestro equipo técnico está revisando el error. Mientras tanto, puedes enviarnos los documentos por correo.',
  },
];

export const proyectos: ProyectoConstructora[] = [
  {
    id: 'P-001',
    name: 'Torres del Parque',
    city: 'Bogotá',
    units: 120,
    priceRangeMin: 450000000,
    priceRangeMax: 780000000,
    leadsGenerated: 245,
    hipotecarioInterest: 78,
    avgScore: 712,
    conversionRate: 12.4,
    status: 'activo',
    constructora: 'Constructora Andina',
    tipoVivienda: 'apartamento',
  },
  {
    id: 'P-002',
    name: 'Villa Serena',
    city: 'Medellín',
    units: 45,
    priceRangeMin: 620000000,
    priceRangeMax: 1200000000,
    leadsGenerated: 189,
    hipotecarioInterest: 92,
    avgScore: 745,
    conversionRate: 18.7,
    status: 'activo',
    constructora: 'Proyectos del Valle',
    tipoVivienda: 'casa',
  },
  {
    id: 'P-003',
    name: 'Centro Empresarial Norte',
    city: 'Barranquilla',
    units: 80,
    priceRangeMin: 350000000,
    priceRangeMax: 650000000,
    leadsGenerated: 156,
    hipotecarioInterest: 45,
    avgScore: 678,
    conversionRate: 8.3,
    status: 'activo',
    constructora: 'Grupo Inmobiliario del Caribe',
    tipoVivienda: 'oficina',
  },
  {
    id: 'P-004',
    name: 'Residencias del Lago',
    city: 'Cali',
    units: 200,
    priceRangeMin: 280000000,
    priceRangeMax: 520000000,
    leadsGenerated: 312,
    hipotecarioInterest: 65,
    avgScore: 634,
    conversionRate: 10.1,
    status: 'activo',
    constructora: 'Constructora Pacífico',
    tipoVivienda: 'apartamento',
  },
  {
    id: 'P-005',
    name: 'Plaza Comercial Sur',
    city: 'Bogotá',
    units: 35,
    priceRangeMin: 890000000,
    priceRangeMax: 2100000000,
    leadsGenerated: 67,
    hipotecarioInterest: 23,
    avgScore: 789,
    conversionRate: 5.2,
    status: 'pausado',
    constructora: 'Inversiones Capital',
    tipoVivienda: 'local',
  },
];

export const leadsInmobiliarios: LeadInmobiliario[] = Array.from({ length: 16 }, (_, i) => {
  const score = Math.floor(400 + Math.random() * 550);
  let priority: 'baja' | 'media' | 'alta' | 'maxima';
  if (score <= 550) priority = 'baja';
  else if (score <= 700) priority = 'media';
  else if (score <= 850) priority = 'alta';
  else priority = 'maxima';

  const statuses: LeadInmobiliario['status'][] = ['pendiente', 'contactado', 'en-proceso', 'documentacion', 'viable', 'aprobado', 'perdido'];
  const tiposVivienda: LeadInmobiliario['tipoVivienda'][] = ['apartamento', 'casa', 'local', 'oficina'];

  return {
    id: `LI-${2000 + i}`,
    name: `${random(firstNames)} ${random(lastNames)}`,
    phone: `3${Math.floor(100000000 + Math.random() * 900000000)}`,
    email: `lead${i}@email.com`,
    capacidadCompra: Math.floor(200000000 + Math.random() * 1500000000),
    score,
    hipotecarioInterest: Math.random() > 0.3,
    ingresosEstimados: Math.floor(3000000 + Math.random() * 20000000),
    city: random(cities),
    tipoVivienda: random(tiposVivienda),
    priority,
    proyecto: random(proyectos).name,
    status: random(statuses),
    lastActivity: randomDate(10),
    assignedTo: random(ejecutivos),
    createdAt: randomDate(45),
  };
});

export { productNames, clientTypeNames, statusNames, banks, cities, ejecutivos };
